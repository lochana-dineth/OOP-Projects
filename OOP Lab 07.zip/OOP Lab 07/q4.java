import java.util.*;
public class q4 
{
    public static void main(String[] args)
    {
    Scanner my_scan = new Scanner(System.in);
    
    System.out.println("Enter the String");
    String input = my_scan.nextLine();
    
    String inputarr[] = input.split(" ");
    String f_name = inputarr[0];
    String l_name = inputarr[1];

    System.out.println("Output : "+f_name.substring(0,1)+" "+l_name.toUpperCase());

    }


}