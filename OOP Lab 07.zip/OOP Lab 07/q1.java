import java.util.*;
class ex1
{
    public static void main(String[] args)
    {
      Scanner my_scan = new Scanner(System.in);

      System.out.print("Please enter a String : ");
      String input = my_scan.nextLine();
      
      int length = input.length();

      for (int i=0; i<length; i++)
      {
       System.out.println(input.charAt(i)); 
      }

    }
}