import java.util.*;
public class q3 
{
    public static void main(String[] args)
    {
        Scanner my_scan = new Scanner(System.in);

        System.out.println("Please Enter a String : ");
        String input = my_scan.nextLine();

        System.out.println("Enter the position of the Char : ");
        int position = my_scan.nextInt();

        System.out.println("String is : "+input);

        System.out.println("Changed String is : "+delete(input,position));
    }

    static String delete(String word, int ch)
    {
        StringBuffer inputSB = new StringBuffer(word);
        inputSB.delete(ch,ch+1); 
        String output = inputSB.toString(); 

        return output;
    }
}