import java.util.*;
public class q2 
{
    public static void main(String[] args)
    {
    Scanner my_scan = new Scanner(System.in);
    
    System.out.println("Enter a String Please : ");
    String input = my_scan.nextLine();

    System.out.println("Enter the Value for M : ");
    int m = my_scan.nextInt();

    System.out.println("Enter the Value for N : ");
    int n = my_scan.nextInt(); 
    
    String output = (String)input.substring(m,m+n);

    System.out.println(output);

    }
}