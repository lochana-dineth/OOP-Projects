package View;

import Controller.BicycleController;
import Model.Bicycle;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class BicycleView extends JFrame {

    private JPanel panel1;
    private JTextField textField1;
    private JTextField textField2;
    private JButton btnbreak;
    private JButton btnspeed;
    private JButton btnaddbike;
    private JLabel lblGear;
    private JLabel lblSpeed;
    private JLabel lblcurrentspeed;


    //Object Creation
    Bicycle bicycle;
    BicycleController bicycleController;



    public BicycleView() {


        btnbreak.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                double decrement = Double.parseDouble(textField1.getText());
                bicycle.applyBrakes(decrement);
                JOptionPane.showMessageDialog(getRootPane(), "Successfully applied Breaks.");
                lblcurrentspeed.setText(bicycle.toString());

            }
        });

        btnspeed.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                double increment = Double.parseDouble(textField2.getText());
                bicycle.speedup(increment);
                JOptionPane.showMessageDialog(getRootPane(), "Successfully added Speed.","Success Message",0);
                lblcurrentspeed.setText(bicycle.toString());
            }
        });
        btnaddbike.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                double speed = Double.parseDouble(textField1.getText());
                int gear = Integer.parseInt(textField2.getText());

                bicycleController = new BicycleController();
                bicycle = bicycleController.addBicycle((int) gear,speed);
                JOptionPane.showMessageDialog(getRootPane(), "Added a Bicycle", "Success Message",0);
                lblcurrentspeed.setText(bicycle.toString());
            }
        });
    }


    //Main Method
    public static void main(String[] args)
    {
        BicycleView ui = new BicycleView();
        ui.setContentPane(ui.panel1);
        ui.setTitle("Bicycle Manager");
        ui.setSize(800,600);
        ui.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        ui.setVisible(true);
    }


}
