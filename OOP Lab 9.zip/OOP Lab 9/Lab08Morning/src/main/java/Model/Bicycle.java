package Model;

public class Bicycle {
    //Create Attributes
    int Gear;
    double Speed;

    //Create Constructor
    public Bicycle(int Gear, double Speed)
    {
     this.Gear = Gear;
     this.Speed = Speed;
    }

    public void applyBrakes(double decrement)
    {
        this.Speed = Speed - decrement;
    }

    public void speedup(double increment)
    {
        this.Speed = Speed + increment;
    }

    public String toString() {
        return "Current Speed is " + this.Speed + "& Gear is" + this.Gear;
    }


}
