class ex1 {
    public static void main (String[] args)
    {
        int lkr = Integer.parseInt(args[0]);

        System.out.println(lkr + " LKR = "+(lkr/129.26)+" $");
        System.out.println(lkr + " LKR = "+(lkr/132.74)+" Pounds");
        System.out.println(lkr + " LKR = "+(lkr/206.36)+" Euros");
    }
}