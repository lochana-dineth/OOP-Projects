import java.util.Scanner;
public class ex4 {

    public static void main (String[] args)
    {
        Scanner scanner = new Scanner (System.in);

        System.out.println("Enter Weight of a Person");
        double weight = scanner.nextDouble();

        System.out.println("Enter Number of People");
        int nopeople = scanner.nextInt();

        double people_count = 1320 / ((weight*nopeople));

        if ((weight*nopeople)>1320)
        {
            System.out.println("People can't fit in the Lift");
        }
        else
        {
            System.out.println("People can fit in the Lift");
        }

        System.out.println("No of People that can fit is = "+(int)Math.floor(people_count));

    }

}