import java.util.*;
public class ex3 {

    public static void main (String[] args)
    {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Please Enter Item Name"); 
        String name = scanner.nextLine();   
        
        System.out.println("Please Enter Unit Price");  
        double unitprice = scanner.nextDouble();

        System.out.println("Please Enter Quantity");
        int quantity = scanner.nextInt(); 
        
        System.out.println("The Total Price is = "+(unitprice*quantity));
    }

}