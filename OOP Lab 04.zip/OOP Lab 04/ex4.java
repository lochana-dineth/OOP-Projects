public class ex4 
{
    public static void main (String[] args)
    {
        double demand_rate = Double.parseDouble(args[0]);
        double setup_cost = Double.parseDouble(args[1]);
        double holding_cost = Double.parseDouble(args[2]);

        ex4 obj = new ex4(); 

        double EOQ = obj.CalculateEOQ(demand_rate, setup_cost, holding_cost);
        double TBO = obj.CalculateTBO(demand_rate, setup_cost, holding_cost);


        System.out.println("EOQ is = "+EOQ);

        System.out.println("TBO is = "+TBO);

    }

     double CalculateEOQ(double demand_rate, double setup_cost, double holding_cost)
    {
        double EOQ = Math.sqrt((2*demand_rate*setup_cost)/holding_cost);
        return EOQ;
    
    }

    double CalculateTBO(double demand_rate,double setup_cost, double holding_cost)
    {
       double TBO = Math.sqrt((2*setup_cost)/demand_rate*holding_cost);
       return TBO;
    
    }


}