
public class ex5 
{
    public static void main (String[] args)
    {

     genrandom();

    }



    static void genrandom()
    {
     {   
        for(int i=0;i<5;i++)
        {   
        double a = (Math.random()*100);
        int b = (int)Math.round(a);
        System.out.println("Number "+i+" is "+b);
        }
     }   
    }

}    
