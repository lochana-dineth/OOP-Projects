import java.util.*;
public class ex6 
{
    public static void main (String[] args)
    {
      Scanner scanner = new Scanner (System.in);  
      
      System.out.println("Please enter a number :");
      int num = scanner.nextInt();
      
      if ((num >=3) && (num <=5))
      {
        System.out.println("Season is Spring");
      }
      else if ((num >=6) && (num <=8))
      {
        System.out.println("Season is Summer");  
      }
      else if ((num >=9) && (num <=11))
      {
        System.out.println("Season is Autumn");  
      } 
      else
      {
        System.out.println("Season is Winter");  
      }     
    }

    static void func()
    {

    }

}