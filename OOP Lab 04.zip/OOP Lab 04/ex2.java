
public class ex2 
{
    public static void main (String[] args)
    {
        int a = Integer.parseInt(args[0]);
        int b = Integer.parseInt(args[1]);

        if (a>b)
        {
            System.out.println("B is the smallest Value");
        }
        else
        {
            System.out.println("A is the smallest Value");
        }

/*
*/
    }


}