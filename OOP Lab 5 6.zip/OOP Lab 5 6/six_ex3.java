import java.util.*;
class six_ex3
{
    public static void main (String[] args)
    {
        Scanner my_scan = new Scanner(System.in);
        String input = my_scan.nextLine();

        //Creating an Array
        char[] input_array = input.toCharArray();

        int a_count = 0;
        int e_count = 0;
        int i_count = 0;
        int o_count = 0;
        int u_count = 0;  

        for (int i=0; i<10 ; i++ )
        {

          if (Objects.equals(input_array[i],'a') == true)
            a_count = a_count + 1;
          if (Objects.equals(input_array[i],'e') == true)
            e_count = e_count + 1;
          if (Objects.equals(input_array[i],'i') == true)
            i_count = i_count + 1;
          if (Objects.equals(input_array[i],'o') == true)
            o_count = o_count + 1;
          if (Objects.equals(input_array[i],'u') == true)
            u_count = u_count + 1;        
            
        }

       // System.out.println(a_count);
       // System.out.println(e_count);
       //  System.out.println(i_count);
       //  System.out.println(o_count);        
       //  System.out.println(u_count); 

        System.out.print("a =");
        for (int i =0 ; i<a_count ; i++ )
        {
            System.out.print("*");
        }
        System.out.println(" ");


        System.out.print("e =");
        for (int i =0 ; i<e_count ; i++ )
        {
            System.out.print("*");
        }
        System.out.println(" ");


        System.out.print("i =");
        for (int i =0 ; i<i_count ; i++ )
        {
            System.out.print("*");
        }
        System.out.println(" ");


        System.out.print("o =");
        for (int i =0 ; i<o_count ; i++ )
        {
            System.out.print("*");
        }
        System.out.println(" ");
 

        System.out.print("u =");
        for (int i =0 ; i<u_count ; i++ )
        {
            System.out.print("*");
        }
        System.out.println(" ");

    }
}