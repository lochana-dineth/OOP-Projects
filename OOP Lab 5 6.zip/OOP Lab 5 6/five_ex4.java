import java.util.*;
class five_ex4
{
    public static void main (String[] args)
    {
        Scanner my_scan = new Scanner(System.in);
        double Value_1,Value_2,Value_3 = 0;

        for (int i=1; i<4; i++)
        {
          System.out.println("Enter the Value "+i);
          Value_i = my_scan.nextdouble();
          double total = 0;
          int count =0;

          if (value_i == 'Q')
          {
            break;
          }
          else
          {
            total = total + Value_i;
            count = count + 1;
          }

        }

        System.out.println("Answer is "+CalculateMean(total,count));


    }

    static double CalculateMean(double total, int count)
    {
       double finalval = total/count;
       return finalval;
    }

}