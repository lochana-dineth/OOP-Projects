import java.util.*;
class five_ex3
{
    public static void main(String[] args)
    {
        Scanner my_scan = new Scanner(System.in);
        System.out.println("Enter the Balance");
        int balance = my_scan.nextInt();

        System.out.println("Your final balance is "+CalculateBalance(balance));
    }

    static double CalculateBalance(int num)
    {
        double finalbalance = 0;
        if (num>50000)
            finalbalance = num + (8/100 * num);
        else if ((num>25000) && (num<=50000))
            finalbalance = num + (5/100 * num);
        else if ((num>10000) && (num<=25000))
            finalbalance = num + (2/100 * num);
        else
            finalbalance = num;            

        return finalbalance;
    }



}