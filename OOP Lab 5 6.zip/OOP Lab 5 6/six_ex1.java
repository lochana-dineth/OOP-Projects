import java.util.*;
class six_ex1
{
    public static void main (String[] args)
    {
        Scanner my_scan = new Scanner(System.in);

        for (int i=0; i<11; i++)
        {
          for (int j=0; j<11; j++)
          {
            for (int k=0; k<11; k++)
            {
               System.out.print(i+","+j+","+k+" | ");
            }


          }
            System.out.println(" End of Combination Group");
        }
    }

}