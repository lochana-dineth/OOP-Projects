import java.util.*;
class five_ex1
{

	
	public static void main(String[] args)
	{
		Scanner my_scan = new Scanner (System.in);
		int input = my_scan.nextInt();

		System.out.println("Your marks are "+input);

		calculategrade(input);
	}

	static void calculategrade(int marks) {
		if (marks >=80 && marks<=100)
			System.out.println("Distinction");
		else if (marks >=60 && marks<=79)
			System.out.println("Honors");
		else if (marks >=50 && marks<=59)
			System.out.println("Merit");
		else if (marks >=40 && marks<=49)
			System.out.println("Pass");
		else if (marks >0 && marks<=39)			
			System.out.println("Fail");
		else
			System.out.println("Invalid");
	}

}