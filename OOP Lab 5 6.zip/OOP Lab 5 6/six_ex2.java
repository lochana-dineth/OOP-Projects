import java.util.*;
class six_ex2
{
    public static void main (String[] args)
    {
        Scanner my_scan = new Scanner(System.in);
        String t = "Y";

      while (t == "Y")
      {
        System.out.println("Enter the Name of the Employee");
        String name = my_scan.nextLine();

        System.out.println("Enter Employee Age");
        int age = my_scan.nextInt();

        System.out.println("Enter Employee Department");
        String department = my_scan.nextLine();

        System.out.println(" ");
        System.out.println(" ");
        System.out.println(" ");

        System.out.println("Employee name is "+name);
        System.out.println("Employee age is "+age);
        System.out.println("Employee department is"+department);
        System.out.println(" ");
        System.out.println(" ");

        System.out.println("Do you want to enter again?");
        t = my_scan.nextLine();
      }
    }
}