import java.util.*;
class ex3 
{
    public static void main(String[] args)
    {
        Scanner my_scan = new Scanner (System.in);
        String input = my_scan.nextLine();

        String area_code = input.substring(0,3);
        String service_code = input.substring(3,4);
        String number_code = input.substring(4,10);                



        System.out.println("Area Code is "+area_code);
        System.out.println("Service Code is "+service_code);
        System.out.println("Number Code is "+number_code);
        String number_code_a = number_code.substring(0,3);
        String number_code_b = number_code.substring(3,6);


        System.out.println("The Complete Phone Number is : "+"("+area_code+") "+service_code+" "+number_code_a+" "+number_code_b);

    }

}