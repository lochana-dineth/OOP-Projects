import java.util.*;
class q2
{
    public static void main(String[] args)
    {
       Scanner my_scan = new Scanner(System.in);
       String input = my_scan.nextLine();

       int length = input.length();
       System.out.println("length is "+length);
       String reverse ="";
       char reverse_letter ;

       for (int i=length; i>0; i=i-1)
       {
         reverse_letter = input.charAt(i-1);
         reverse = reverse + reverse_letter;
       }

       System.out.println(input);
       System.out.println(reverse);

    }
}