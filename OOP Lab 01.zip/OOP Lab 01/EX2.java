
public class EX2 {
    public static void main (String[] args)
    {
        System.out.println("Hello World!");
        System.out.println("It's been nice knowing you");
        System.out.println("Goodbye World!");

        System.out.println("Hello World!\nIt's been nice knowing you.\nGoodbye world!");
    }
}