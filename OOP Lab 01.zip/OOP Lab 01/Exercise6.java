
public class Exercise6 {
    public static void main (String[] args){

        int a = 40;
        int b = 100;
        double c = 24.3;
        double d = 90.5;
        
        System.out.println("Variable A is "+a);
        System.out.println("Variable B is "+b);
        System.out.println("Variable C is "+c);
        System.out.println("Variable D is "+d);

        System.out.println("Addition of the Numbers!");
        System.out.println("A + C = "+ (a+c));
        System.out.println("B + D = "+ (b+d));
        System.out.println("Division of the Numbers!");
        System.out.println("A - C = "+ (a-c));
        System.out.println("B - D = "+ (b-d));
        System.out.println("Multipication of the Numbers!");
        System.out.println("A * C = "+ (a*c));
        System.out.println("B * D = "+ (b*d));
        System.out.println("Division of the Numbers!");
        System.out.println("A / C = "+ (a/c));
        System.out.println("B / D = "+ (b/d));        

    }
}