
public class Exercise5 {
    public static void main (String[] args){
        double aa = 50.250;
        double ab = 25.500;

        System.out.println("Total is "+ aa + ab);
        System.out.println("Average is "+ (aa + ab)/2);
        System.out.println("Sum of Squares is "+ (aa*aa + ab*ab));
    }

}