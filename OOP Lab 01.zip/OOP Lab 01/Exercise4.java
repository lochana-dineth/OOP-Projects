
public class Exercise4 {
    public static void main (String[] args)
    {
        int aa = 50;
        String ab = "Hello";
        double ac = 50.00;

        System.out.println("Integer is "+ aa);
        System.out.println("String is "+ ab);
        System.out.println("Double is "+ ac);
    }
}