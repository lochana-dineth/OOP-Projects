//We can use the 'final' prefix in variables to create a Constant Variable
//By using this we can use commonly used values easily with less effort

class distance_converter_constants {
    public static void main (String[] args)
    {
        
        final double km_per_mile = 1.069;
        final double yards_per_mile = 1760.0;
        int miles = 26;
        int yards = 385;
        double km = 0;

        km = (miles * km_per_mile) + ((yards / yards_per_mile )*km_per_mile);

        System.out.println("The number of Kilometeres in " + miles+" Miles and "+yards+" Yards is = "+km+" Kilometeres");
    }

}