
class args_display {
        public static void main (String[] args)
        {
            for(int i=0;i<=1;i++)  
            {
            System.out.println(args[i]);
            }

            System.out.println("The Length of the Command Line Arguments are "+args.length);
        }
}