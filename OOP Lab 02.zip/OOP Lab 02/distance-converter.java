
class distance_converter {
    public static void main (String[] args)
    {
        int miles = 26;
        int yards = 385;
        double km = 0;

        km = (1.069 * miles) + ((yards / 1760.0 )*1.069);

        System.out.println("The number of Kilometeres in " + miles+" Miles and "+yards+" Yards is = "+km+" Kilometeres");
    }
}