class Output
{
    public static void main(String[] args)
    {
        int a, b;
        a = 65;                                
        b = 78;                    
        System.out.println(29/4);               
        System.out.println(3.0/2);              
        System.out.print("Hello there.\n");     
        System.out.println(7);                  
        System.out.println(3+5);                
        System.out.print("3+5");                
        System.out.println();                   
        System.out.println(2+3*6);              
        System.out.println("a");                
        System.out.println(a);                  
        System.out.println(b);                  
    }
}