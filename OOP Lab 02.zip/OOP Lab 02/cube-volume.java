
class cube_volume {
    public static void main (String[] args)
    {
        double length =  Double. parseDouble(args[0]);
        double width =  Double. parseDouble(args[1]);
        double height =  Double. parseDouble(args[2]);

        double volume = length * width * height;

        System.out.println("The Volume of the Cube is "+volume);

    }

}