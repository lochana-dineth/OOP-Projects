
class temperature_convert {
    public static void main (String[] args)
    {
        //System.out.println("You must have entered the Value of Temperature as a Command Line Argument!");

        double temp_celcius=Integer.parseInt(args[0]);

        double temp_farenheit = 1.8 *temp_celcius +32;

        System.out.println("The Value of "+temp_celcius+" Celcius in Farenheit is "+temp_farenheit+" Farenheit!");

    }
}